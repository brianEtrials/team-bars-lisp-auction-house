import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const fetchbids = (item_ID) => {
    return new Promise((resolve, reject) => {
        console.log("Fetching bids for item_ID:", item_ID);
        const sql = 'SELECT * FROM bids WHERE item_ID = ?;';
        pool.query(sql, [item_ID], (error, result) => {
            if (error) {
                console.error("Database query error:", error);
                return reject(error);
            }

            if (result.length === 0) {
                console.log("No bids found for item_ID:", item_ID);
                return resolve({ bids: [] });
            }

            const bids = result.map((bid) => ({
                bid_ID: bid.bid_ID,
                buyer_ID: bid.buyer_ID,
                item_ID: bid.item_ID,
                amount: bid.amount,
                bidTimestamp: bid.bidTimestamp
                    ? new Date(bid.bidTimestamp * 1000).toISOString().split('T')[0]
                    : null,
            }));

            console.log("Bids found:", bids);
            return resolve({ bids });
        });
    });
};

export const handler = async (event) => {
    console.log("Received event:", event);

    let item_ID;

    // Extract item_ID from different possible formats
    try {
        if (event.body) {
            // Handle case where body is a JSON string
            const parsedBody = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            item_ID = parsedBody.item_ID;
        } else if (event.item_ID) {
            // Handle case where item_ID is directly in the event
            item_ID = event.item_ID;
        }
    } catch (parseError) {
        console.error("Failed to parse event body:", parseError);
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Invalid request body" }),
        };
    }

    // Validate item_ID
    if (!item_ID || typeof item_ID !== 'number') {
        console.error("Invalid or missing item_ID:", item_ID);
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Valid item_ID is required" }),
        };
    }

    try {
        const biddata = await fetchbids(item_ID);
        console.log("Bids fetched are:", biddata);
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ biddata }),
        };
    } catch (error) {
        console.error("Database error:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
                message: "Failed to load bids",
                error: error.message,
            }),
        };
    }
};
