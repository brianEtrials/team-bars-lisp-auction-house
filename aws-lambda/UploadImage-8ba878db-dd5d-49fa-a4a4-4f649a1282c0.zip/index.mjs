import AWS from 'aws-sdk';
const s3 = new AWS.S3();

export const handler = async (event) => {
    try {
        let base64Image;

        // Check if `base64Image` is directly in `event.body` or nested
        if (event.base64Image) {
            base64Image = event.base64Image;
        } else {
            const parsedBody = JSON.parse(event.body || '{}');
            base64Image = parsedBody.base64Image;
        }

        // Throw an error if base64Image is still undefined
        if (!base64Image) {
            throw new Error("base64Image is required");
        }

        const buffer = Buffer.from(base64Image, 'base64');
        const params = {
            Bucket: 'uploadimage24',
            Key: `uploads/${Date.now()}.jpg`,
            Body: buffer,
            ContentEncoding: 'base64',
            ContentType: 'image/jpeg'
        };

        await s3.putObject(params).promise();

        const imageUrl = `https://${params.Bucket}.s3.amazonaws.com/${params.Key}`;
        
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Image uploaded successfully', imageUrl })
        };
    } catch (err) {
        console.error(err);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: 'Error uploading image', error: err.message || err })
        };
    }
};
