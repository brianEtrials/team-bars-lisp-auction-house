import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to add an account to the database, now with username and password
const addAccount = (firstName, lastName, email, funds, accountType, username, password, status, freeFunds) => {
    return new Promise((resolve, reject) => {
        const sql = `INSERT INTO accounts (first_name, last_name, email, funds, account_type, username, password, status, freeFunds)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`;
        pool.query(sql, [firstName, lastName, email, funds, accountType, username, password, status, freeFunds], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

// Main handler function
export const handler = async (event) => {
    // Parse and prepare data from the event
    let firstName = String(event.firstName);
    let lastName = String(event.lastName);
    let email = String(event.email);
    let funds = Number(event.funds);
    let accountType = event.accountType === 'buyer' || event.accountType === 'seller' ? event.accountType : null;
    let username = String(event.username);
    let password = String(event.password);
    let status = Boolean(event.status);
    let freeFunds = Number(event.funds);

    // Check for required fields
    if (!firstName || !lastName || !email || !accountType || !username || !password || !status) {
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: "Missing required fields: firstName, lastName, email, accountType, username, password, and status must be provided."
            })
        };
    }

    // Log the account data before inserting into the database
    console.log('Inserting account:', { firstName, lastName, email, funds, accountType, username });

    try {
        // Add the account to the database
        const result = await addAccount(firstName, lastName, email, funds, accountType, username, password, status, freeFunds);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Account added successfully",
                accountId: result.insertId // Capture and return the ID of the newly inserted account
            })
        };
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to add account",
                error: error.message
            })
        };
    }
};
