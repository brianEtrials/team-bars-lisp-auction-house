
import mysql from 'mysql';

const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const closeAccount = (idaccounts) => {
    return new Promise((resolve, reject) => {
        const sql = `
            UPDATE auction_data.accounts 
            SET status = false 
            WHERE idaccounts = ? 
            AND (
                EXISTS (
                    SELECT 1 
                    FROM auction_data.items 
                    WHERE seller_id = ? 
                    AND iStatus = 'inactive'
                ) 
                OR EXISTS (
                    SELECT 1 
                    FROM auction_data.items i
                    JOIN auction_data.bids n ON i.item_ID = n.item_ID
                    WHERE n.buyer_ID = ? 
                    AND i.iStatus = 'inactive'
                )
            );
        `;
        pool.query(sql, [idaccounts, idaccounts, idaccounts], (error, results) => {
            if (error) return reject(error);

            if (results.affectedRows === 0) {
                // Check for active items or bids
                const checkItemSql = `
                    SELECT iStatus 
                    FROM auction_data.items 
                    WHERE seller_id = ? 
                    LIMIT 1;
                `;
                const checkBidSql = `
                    SELECT 1 
                    FROM auction_data.items i
                    JOIN auction_data.bids n ON i.item_ID = n.item_ID
                    WHERE n.buyer_ID = ? 
                    LIMIT 1;
                `;
                pool.query(checkItemSql, [idaccounts], (itemError, itemResults) => {
                    if (itemError) return reject(itemError);
                    if (itemResults.length > 0) {
                        return reject(new Error("Item is active, cannot close account"));
                    } else {
                        pool.query(checkBidSql, [idaccounts], (bidError, bidResults) => {
                            if (bidError) return reject(bidError);
                            if (bidResults.length > 0) {
                                return reject(new Error("Active bids exist, cannot close account"));
                            } else {
                                // No active items or bids, check for no associated items or bids
                                const noItemsSql = `
                                    SELECT 1 
                                    FROM auction_data.items 
                                    WHERE seller_id = ?
                                    LIMIT 1;
                                `;
                                const noBidsSql = `
                                    SELECT 1 
                                    FROM auction_data.bids 
                                    WHERE buyer_ID = ?
                                    LIMIT 1;
                                `;
                                pool.query(noItemsSql, [idaccounts], (noItemError, noItemResults) => {
                                    if (noItemError) return reject(noItemError);
                                    if (noItemResults.length === 0) {
                                        // No items, now check for bids
                                        pool.query(noBidsSql, [idaccounts], (noBidError, noBidResults) => {
                                            if (noBidError) return reject(noBidError);
                                            if (noBidResults.length === 0) {
                                                // No items or bids exist, close the account
                                                const forceCloseSql = `
                                                    UPDATE auction_data.accounts 
                                                    SET status = false 
                                                    WHERE idaccounts = ?;
                                                `;
                                                pool.query(forceCloseSql, [idaccounts], (forceError, forceResults) => {
                                                    if (forceError) return reject(forceError);
                                                    if (forceResults.affectedRows > 0) {
                                                        return resolve({ message: "Account closed successfully (no items or bids associated)" });
                                                    } else {
                                                        return reject(new Error("Failed to close account, please try again"));
                                                    }
                                                });
                                            } else {
                                                return reject(new Error("Active bids exist, cannot close account"));
                                            }
                                        });
                                    } else {
                                        return reject(new Error("Item is active, cannot close account"));
                                    }
                                });
                            }
                        });
                    }
                });
            } else {
                resolve({ message: "Account closed successfully" });
            }
        });
    });
};

export const handler = async (event) => {
    let idaccounts = Number(event.idaccounts);
    console.log("idaccounts", idaccounts);

    if (!idaccounts) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "idaccounts is required" }),
        };
    }

    try {
        const response = await closeAccount(idaccounts);
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify(response),
        };
    } catch (error) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: error.message }),
        };
    }
};


// import mysql from 'mysql';

// const pool = mysql.createPool({
//     host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
//     user: "auctionAdmin",
//     password: "bars:auction",
//     database: "auction_data"
// });

// const closeAccount = (idaccounts) => {
//     return new Promise((resolve, reject) => {
//         const sql = `
//             UPDATE auction_data.accounts 
//             SET status = false 
//             WHERE idaccounts = ? 
//             AND (
//                 EXISTS (
//                     SELECT 1 
//                     FROM auction_data.items 
//                     WHERE seller_id = ? 
//                     AND iStatus = 'inactive'
//                 ) 
//                 OR EXISTS (
//                     SELECT 1 
//                     FROM auction_data.items i
//                     JOIN auction_data.bids n ON i.item_ID = n.item_ID
//                     WHERE n.buyer_ID = ? 
//                     AND i.iStatus = 'inactive'
//                 )
//             );
//         `;
//         pool.query(sql, [idaccounts, idaccounts, idaccounts], (error, results) => {
//             if (error) return reject(error);

//             if (results.affectedRows === 0) {
//                 // Check if the reason is due to active items or active bids
//                 const checkItemSql = `
//                     SELECT iStatus 
//                     FROM auction_data.items 
//                     WHERE seller_id = ? 
//                     AND iStatus = 'active'
//                     LIMIT 1;
//                 `;
//                 const checkBidSql = `
//                     SELECT 1 
//                     FROM auction_data.items i
//                     JOIN auction_data.bids n ON i.item_ID = n.item_ID
//                     WHERE n.buyer_ID = ? 
//                     AND i.iStatus = 'active'
//                     LIMIT 1;
//                 `;
//                 pool.query(checkItemSql, [idaccounts], (itemError, itemResults) => {
//                     if (itemError) return reject(itemError);
//                     if (itemResults.length > 0) {
//                         return reject(new Error("Item is active, cannot close account"));
//                     } else {
//                         pool.query(checkBidSql, [idaccounts], (bidError, bidResults) => {
//                             if (bidError) return reject(bidError);
//                             if (bidResults.length > 0) {
//                                 return reject(new Error("Active bids exist, cannot close account"));
//                             } else {
//                                 return reject(new Error("Account not found or no active items/bids exist"));
//                             }
//                         });
//                     }
//                 });
//             } else {
//                 resolve({ message: "Account closed successfully" });
//             }
//         });
//     });
// };

  
// export const handler = async (event) => {
//     let idaccounts = Number(event.idaccounts);
//     console.log("idaccounts",idaccounts)
//     // let buyer_username = event.username
//     // const buyer_IDresult = await readid(buyer_username); //Sharvi

//     if (!idaccounts) {
//         return {
//             statusCode: 400,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify({ message: "idaccounts is required" })
//         };
//     }

//     try {
//         const response = await closeAccount(idaccounts);
//         return {
//             statusCode: 200,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify(response)
//         };
//     } catch (error) {
//         return {
//             statusCode: 400,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify({ message: error.message })
//         };
//     }
// };


// - working for close seller account-----------------------------------------
// import mysql from 'mysql';

// const pool = mysql.createPool({
//     host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
//     user: "auctionAdmin",
//     password: "bars:auction",
//     database: "auction_data"
// });

// const closeAccount = (idaccounts) => {
//     return new Promise((resolve, reject) => {
//         const sql = `
//             UPDATE auction_data.accounts 
//             SET status = false 
//             WHERE idaccounts = ? 
//             AND EXISTS (
//                 SELECT 1 
//                 FROM auction_data.items 
//                 WHERE seller_id = ? 
//                 AND iStatus = 'inactive'
//             );
//         `;
//         pool.query(sql, [idaccounts, idaccounts], (error, results) => {
//             if (error) return reject(error);

//             if (results.affectedRows === 0) {
//                 // Check if the reason is due to an active item
//                 const checkItemSql = `
//                     SELECT iStatus 
//                     FROM auction_data.items 
//                     WHERE seller_id = ? 
//                     AND iStatus = 'active'
//                     LIMIT 1;
//                 `;
//                 pool.query(checkItemSql, [idaccounts], (itemError, itemResults) => {
//                     if (itemError) return reject(itemError);
//                     if (itemResults.length > 0) {
//                         return reject(new Error("Item is active, cannot close account"));
//                     } else {
//                         return reject(new Error("Account not found or no active items exist"));
//                     }
//                 });
//             } else {
//                 resolve({ message: "Account closed successfully" });
//             }
//         });
//     });
// };

// export const handler = async (event) => {
//     let idaccounts = Number(event.idaccounts);

//     if (!idaccounts) {
//         return {
//             statusCode: 400,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify({ message: "idaccounts is required" })
//         };
//     }

//     try {
//         const response = await closeAccount(idaccounts);
//         return {
//             statusCode: 200,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify(response)
//         };
//     } catch (error) {
//         return {
//             statusCode: 400,
//             headers: {
//                 "Access-Control-Allow-Origin": "*",
//             },
//             body: JSON.stringify({ message: error.message })
//         };
//     }
// };



// - working for close seller account-----------------------------------------


// import mysql from 'mysql';

// const pool = mysql.createPool({
//     host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
//     user: "auctionAdmin",
//     password: "bars:auction",
//     database: "auction_data"
// });

// const closeAccount = (idaccounts) => {
//     return new Promise((resolve, reject) => {
//         const sqlAccount = `
//             UPDATE auction_data.accounts 
//             SET status = false 
//             WHERE idaccounts = ?;
//         `;
        
//         const sqlItems = `
//             UPDATE auction_data.items 
//             SET iStatus = 'inactive' 
//             WHERE seller_id = ? AND iStatus = 'active';
//         `;

//         pool.query(sqlAccount, [idaccounts], (error, accountResults) => {
//             if (error) {
//                 console.error("Account update query error:", error);
//                 return reject(error);
//             }

//             console.log("Account update results:", accountResults);

//             if (accountResults.affectedRows === 0) {
//                 return reject(new Error("Account not found"));
//             }

//             pool.query(sqlItems, [idaccounts], (error, itemResults) => {
//                 if (error) {
//                     console.error("Items update query error:", error);
//                     return reject(error);
//                 }

//                 console.log("Items update results:", itemResults);

//                 resolve({
//                     message: "Account and associated items closed successfully",
//                     itemsUpdated: itemResults.affectedRows
//                 });
//             });
//         });
//     });
// };

// export const handler = async (event) => {
//     const idaccounts = Number(event.idaccounts);

//     if (!idaccounts) {
//         return {
//             statusCode: 400,
//             headers: {
//                 "Access-Control-Allow-Origin": "*"
//             },
//             body: JSON.stringify({ message: "idaccounts is required" })
//         };
//     }

//     try {
//         const response = await closeAccount(idaccounts);
//         return {
//             statusCode: 200,
//             headers: {
//                 "Access-Control-Allow-Origin": "*"
//             },
//             body: JSON.stringify(response)
//         };
//     } catch (error) {
//         return {
//             statusCode: 404,
//             headers: {
//                 "Access-Control-Allow-Origin": "*"
//             },
//             body: JSON.stringify({ message: error.message })
//         };
//     }
// };
