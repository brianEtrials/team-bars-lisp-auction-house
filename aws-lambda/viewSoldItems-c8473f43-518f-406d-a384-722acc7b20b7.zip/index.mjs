import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const fetchitems = (lowrange,currenttime) =>{
  return new Promise((resolve,reject)=>{
    // const sql ='Select * FROM items WHERE iStatus = "fulfilled" AND iFullfilledTime>=? AND iFullfilledTime<=?;'
    const sql ='Select * FROM items WHERE iFullfilledTime IS NOT NULL  AND iFullfilledTime>=? AND iFullfilledTime<=?;'

    pool.query(sql,[lowrange,currenttime],(error,result) => {
      if (error) return reject(error);

      if (result.length === 0 ){
        return resolve({items:[]})
      }
      const items = result.map(item =>({
        ...item,
        iStartDate: item.iStartDate ? new Date(item.iStartDate * 1000).toISOString().split('T')[0]:null,
        iEndDate: item.iEndDate ? new Date(item.iEndDate * 1000).toISOString().split('T')[0]:null,
      }))

      return resolve({items})
    });
  });
};


export const handler = async (event) => {
  // TODO implement -24 hour
  // const lasttwofour = 24 ? Number(event.lasttwofour) * 24 * 60 * 60 : null; // Convert days to seconds
  const lasttwofour = 24 * 60 * 60;
  let currenttime = Math.floor(new Date().getTime() / 1000);
  let lowrange = currenttime - lasttwofour;
  console.log("current time",currenttime,"lower range",lowrange)

  
  try{
    const itemdata = await fetchitems(lowrange,currenttime);
    console.log("Items fetched are : ", itemdata)
    const response = {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
    },
      body: JSON.stringify({itemdata}),
    };
    return response;
  }
  catch(error){
    console.error("Database error : ", error);
    return{
      statusCode:500,
      headers: {
        "Access-Control-Allow-Origin": "*",
    },
      body: JSON.stringify({
        message:"Failed to load items",
        error: error.message,
      })
    }

  }

};
