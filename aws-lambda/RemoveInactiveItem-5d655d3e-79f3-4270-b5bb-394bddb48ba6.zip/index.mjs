import mysql from 'mysql'

export const handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});
  
  let DeleteConstant = (item_ID) => {
      return new Promise((resolve, reject) => {
            pool.query("DELETE FROM items WHERE item_ID = ? AND iStatus = 'inactive'", [item_ID], (error, rows) => {
                if (error) { return reject(error); }
                if ((rows) && (rows.affectedRows == 1)) {
                    return resolve(true);
                } else {
                    return resolve(false);
                }
            });
      });
  }

  let response
  
  try {
    const result = await DeleteConstant(event.item_ID)
    if (result) {
      response = { statusCode: 200, result: { "success" : true }}
    } else {
      response = { statusCode: 400, error: "No such constant" }
    }
  } catch (err) {
     response = { statusCode: 400, error: err }
  }
    
  pool.end()     // close DB connections

  return response;
}




// export const handler = async (event) => {
//     // Extract item data
//     let item_Id = Number(event.iD);

//     // Proceed with deletion regardless of status
//     const response = {
//         statusCode: 200,
//         body: JSON.stringify({
//             status: "Item Deleted",
//             message: "Item has been successfully deleted",
//             itemData: {
//                 item_Id: item_Id
//             }
//         }),
//     };
//     return response;
// };
