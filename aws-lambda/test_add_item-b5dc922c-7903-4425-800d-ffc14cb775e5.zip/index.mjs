import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to add an item to the database with hardcoded seller_id = 2
const addItem = (itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemStatus, itemType, userid) => {
    return new Promise((resolve, reject) => {
        const sql = `INSERT INTO items (iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType, seller_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`; 
        pool.query(sql, [itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemStatus, itemType, userid], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

const fetchuserID = (username) => {
    return new Promise((resolve, reject) => {
      console.log("Fetching user ID for username:", username);
      
      pool.query("SELECT idaccounts FROM accounts WHERE username=?", [username], (error, rows) => {
        if (error) {
          console.error("Error querying database:", error);
          return reject(error);
        }
        console.log("Database rows fetched:", rows);
  
        // Check if any rows are returned
        if (rows.length === 0) {
          console.warn(`No account found for username: ${username}`);
          return resolve(null); // No account found
        }
  
        return resolve((rows[0].idaccounts)); // Return the first row
      });
    });
};

// Main handler function
export const handler = async (event) => {
    // Parse and prepare data from the event
    const iName = String(event.iName);
    const iDescription = String(event.iDescription);
    const iImage = String(event.iImage); // S3 image URL from front end
    const iStartingPrice = Number(event.iStartingPrice);

    // Check if iStartDate and duration are provided
    const iStartDate = event.iStartDate ? Math.floor(new Date(event.iStartDate).getTime() / 1000) : null;
    const duration = event.duration ? Number(event.duration) * 24 * 60 * 60 : null; // Convert days to seconds
    const iEndDate = (iStartDate && duration) ? iStartDate + duration : null;
    const iStatus = "inactive"; // Default status
    const iType = String(event.iType) || "Auction"; // Default to "Auction" if not provided
    const username = String(event.username);

    // Log the item data before inserting into the database
    console.log('Inserting item:', { iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType, username });

    try {
        // Fetch the user ID for the provided username
        const userid = await fetchuserID(username);
        if (!userid) {
            throw new Error(`User ID not found for username: ${username}`);
        }
        console.log("User ID fetched:", userid);

        // Add the item to the database
        const result = await addItem(iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType, userid);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Item added successfully",
                itemId: result.insertId // Capture and return the ID of the newly inserted item
            })
        };
    } catch (error) {
        // Handle possible errors during database interaction
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to add item",
                error: error.message
            })
        };
    }
};
