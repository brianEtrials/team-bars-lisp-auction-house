import mysql from 'mysql';

// Database connection pool
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Login handler function
const login = (username, password) => {
    return new Promise((resolve, reject) => {
        const sql = `SELECT * FROM accounts WHERE username = ? AND password = ?`;
        pool.query(sql, [username, password], (error, results) => {
            if (error) return reject(error);
            if (results.length === 0) return reject(new Error("Invalid username or password"));

            return resolve(results[0]); // Return the first result only
        });
    });
};

export const handler = async (event) => {
    // Individually map fields from event, ensuring types are correct
    let username = String(event.username);
    let password = String(event.password);

    // Validate fields
    if (!username || !password) {
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Username and password are required" })
        };
    }

    try {
        const response = await login(username, password);
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify(response)
        };
    } catch (error) {
        return {
            statusCode: 401,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: error.message })
        };
    }
};