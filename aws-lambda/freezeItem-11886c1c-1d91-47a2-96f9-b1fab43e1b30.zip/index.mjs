import mysql from 'mysql';

// Create a connection pool
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data",
});

// Function to update item status
const freezeItem = (item_ID) => {
  return new Promise((resolve, reject) => {
    pool.query(
      "UPDATE items SET iStatus = 'frozen' WHERE item_ID = ? AND iStatus = 'active'",
      [item_ID],
      (error, results) => {
        if (error) return reject(error);
        if (results.affectedRows === 0) {
          return reject(new Error("Item not found or not active."));
        }
        resolve({ message: "Item frozen successfully." });
      }
    );
  });
};

// Lambda handler
export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  // Extract item_ID directly from the event
  const item_ID = Number(event.item_ID);

  if (isNaN(item_ID)) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid item_ID provided." }),
    };
  }

  try {
    // Call the freezeItem function
    const response = await freezeItem(item_ID);

    // Return success response
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify(response),
    };
  } catch (error) {
    console.error("Error freezing item:", error.message);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error.message }),
    };
  }
};
