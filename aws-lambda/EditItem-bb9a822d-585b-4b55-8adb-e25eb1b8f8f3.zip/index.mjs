import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to read funds and other details from the database
const readfunds = () => {
  return new Promise((resolve, reject) => { 
      pool.query("SELECT first_name, last_name, email, funds FROM accounts WHERE idaccounts = '1'", [], (error, rows) => {
          if (error) { return reject(error); }
          return resolve(rows[0]); // Assuming 'idaccounts' is unique and will return one row
      });
  });
};

// Function to update funds by adding the specified amount to the current funds
const addfunds = (newTotalFunds) => {
  return new Promise((resolve, reject) => {
      const sql = `UPDATE accounts SET funds = ? WHERE idaccounts = '1'`;
      pool.query(sql, [newTotalFunds], (error, results) => {
          if (error) return reject(error);
          return resolve(results);
      });
  });
};

// Handler function for the API call
export const handler = async (event) => {
  try {
    // Fetch current funds from the database
    const account = await readfunds();
    const currentFunds = account.funds;

    // Get the amount to add from the event
    const amountToAdd = parseFloat(event.funds); // Ensure this is a number
    if (isNaN(amountToAdd)) throw new Error("Invalid amount");

    // Calculate new total funds
    const newTotalFunds = currentFunds + amountToAdd;

    // Update funds in the database
    await addfunds(newTotalFunds);

    // Return the updated funds
    const response = {
      statusCode: 200,
      body: JSON.stringify({
        message: "Funds updated successfully",
        newTotalFunds
      }),
    };
    return response;

  } catch (error) {
    // Error handling
    console.error("Error updating funds:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to update funds", error: error.message }),
    };
  }
};

// import mysql from 'mysql';

// // Set up a connection pool to the database
// const pool = mysql.createPool({
//     host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
//     user: "auctionAdmin",
//     password: "bars:auction",
//     database: "auction_data"
// });

// let readfunds = () => {
//   return new Promise((resolve, reject) => { 

//       pool.query("SELECT ,frist_name,last_name,email,funds FROM accounts WHERE idaccounts = '1'", [], (error, rows) => {
//           if (error) { return reject(error); }
//           return resolve(rows);
//       })
//   })
// }

// // Function to add an item to the database
// const addfunds = (addedfunds) => {
//   return new Promise((resolve, reject) => {
//       const sql = `INSERT INTO accounts (funds)
//                    VALUES (?);`;
//       pool.query(sql, [addedfunds], (error, results) => {
//           if (error) return reject(error);
//           return resolve(results);
//       });
//   });
// };


// const all_constants = await readfunds()


// export const handler = async (event) => {
//   let funds = String(event.funds);
//   let inputvalue = String()
//   const response = {
//     statusCode: 200,
//     body: JSON.stringify(result),
//   };
//   return response;
// };