import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to fetch all transactions for a specific buyer_ID
const fetchTransactions = (buyer_ID) => {
    return new Promise((resolve, reject) => {
        console.log("Fetching transactions for buyer_ID:", buyer_ID);
        const sql = 'SELECT * FROM transactions WHERE buyer_id = ?;';
        pool.query(sql, [buyer_ID], (error, result) => {
            if (error) {
                console.error("Database query error:", error);
                return reject(error);
            }

            if (result.length === 0) {
                console.log("No transactions found for buyer_ID:", buyer_ID);
                return resolve({ transactions: [] });
            }

            console.log("Transactions found:", result);
            return resolve({ transactions: result });
        });
    });
};

export const handler = async (event) => {
    console.log("Received event:", event);

    let buyer_ID;

    // Extract buyer_ID from different possible formats
    try {
        if (event.body) {
            // Handle case where body is a JSON string
            const parsedBody = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            buyer_ID = parsedBody.buyer_ID;
        } else if (event.buyer_ID) {
            // Handle case where buyer_ID is directly in the event
            buyer_ID = event.buyer_ID;
        }
    } catch (parseError) {
        console.error("Failed to parse event body:", parseError);
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Invalid request body" }),
        };
    }

    // Validate buyer_ID
    if (!buyer_ID || typeof buyer_ID !== 'number') {
        console.error("Invalid or missing buyer_ID:", buyer_ID);
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Valid buyer_ID is required" }),
        };
    }

    try {
        const transactionData = await fetchTransactions(buyer_ID);
        console.log("Transactions fetched are:", transactionData);
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ transactionData }),
        };
    } catch (error) {
        console.error("Database error:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
                message: "Failed to load transactions",
                error: error.message,
            }),
        };
    }
};
