import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to update the status of the item in the database
const publishItem = (item_ID, duration, iStartDate, iEndDate) => {
    return new Promise((resolve, reject) => {
        const sql = `UPDATE items 
                        SET iStatus = 'active', duration = ?, iStartDate = ?, iEndDate = ? 
                        WHERE item_ID = ?;`;
        pool.query(sql, [duration, iStartDate, iEndDate, item_ID], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

// Main handler function
export const handler = async (event) => {

    let item_Id = Number(event.item_ID);
    let duration = event.durationValue;
    duration = duration * 24 * 60 * 60;
    let iStartDate = Math.floor(new Date().getTime() / 1000);
    let iEndDate = iStartDate + duration;

    if (isNaN(item_Id)) {
      return {
          statusCode: 400,
          body: JSON.stringify({ message: "Invalid item ID" })
      }
    };

    try {

      await publishItem(item_Id, duration, iStartDate, iEndDate);


      const response = {
        statusCode: 200,
        body: JSON.stringify({         
          message: "Item published successfully", 
        }),
      };
      return response;

    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to publish item",
                error: error.message,
            }),
        };
    } 
};