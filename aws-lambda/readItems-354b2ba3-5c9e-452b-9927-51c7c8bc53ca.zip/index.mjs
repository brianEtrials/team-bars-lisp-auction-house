import mysql from 'mysql';

// Create a connection pool
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});

// Function to query active items
const getActiveItemsCount = () => {
  return new Promise((resolve, reject) => {
    pool.query(
      "SELECT COUNT(*) AS activeItemsCount FROM items WHERE iStatus = 'active'",
      (error, rows) => {
        if (error) return reject(error);
        return resolve(rows[0]?.activeItemsCount || 0);
      }
    );
  });
};

// Lambda handler
export const handler = async (event) => {
  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Query the database
    const activeItemsCount = await getActiveItemsCount();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ activeItemsCount }),
    };
  } catch (error) {
    console.error("Error fetching active items count:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Failed to retrieve active items count", error: error.message }),
    };
  }
};
