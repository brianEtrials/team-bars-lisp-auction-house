import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to get items and seller information
const getSellerData = (idfetched) => {
    return new Promise((resolve, reject) => {
        const sql = `
        SELECT 
        items.*, 
        accounts.first_name, 
        accounts.last_name, 
        accounts.email, 
        accounts.funds, 
        COALESCE(MAX(bids.amount), items.iStartingPrice) AS highestBid
    FROM items
    JOIN accounts ON items.seller_id = accounts.idaccounts
    LEFT JOIN bids ON items.item_ID = bids.item_ID
    WHERE items.seller_id = ?
    GROUP BY items.item_ID;    
        `;
        pool.query(sql, [idfetched], (error, results) => {
            if (error) return reject(error);

            if (results.length === 0) {
                return resolve({ items: [], sellerInfo: null });
            }

            // Extract seller information from the first item (all rows have the same seller details)
            const sellerInfo = {
                first_name: results[0].first_name,
                last_name: results[0].last_name,
                email: results[0].email,
                funds: results[0].funds,
            };

            const items = results.map(item => ({
                ...item,
                iStartDate: item.iStartDate ? new Date(item.iStartDate * 1000).toISOString().split('T')[0] : null,
                iEndDate: item.iEndDate ? new Date(item.iEndDate * 1000).toISOString().split('T')[0] : null,
                duration: item.duration ? Math.floor(item.duration / 86400) : null
            }));

            resolve({ items, sellerInfo });
        });
    });
};

// Function to fetch seller ID using username
const fetchId = (usernameFetched) => {
    return new Promise((resolve, reject) => {
        pool.query("SELECT idaccounts, first_name, last_name, email, funds FROM accounts WHERE username=?", [usernameFetched], (error, rows) => {
            if (error) return reject(error);
            
            if (rows.length === 0) {
                return resolve(null); // No user found
            }

            // Return ID, seller info, and funds
            return resolve({
                idaccounts: rows[0].idaccounts,
                first_name: rows[0].first_name,
                last_name: rows[0].last_name,
                email: rows[0].email,
                funds: rows[0].funds,
            });
        });
    });
};


// Main handler function
export const handler = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));

        // Extract the username from queryStringParameters or request body
        const usernameFetched = event.queryStringParameters ? event.queryStringParameters.username : (event.body ? JSON.parse(event.body).username : null);

        console.log("Extracted username:", usernameFetched);

        if (!usernameFetched) {
            return {
                statusCode: 400,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization"
                },
                body: JSON.stringify({ message: "Username is required" }),
            };
        }

        // Fetch seller ID and additional info using the username
        const sellerData = await fetchId(usernameFetched);
        if (!sellerData) {
            return {
                statusCode: 404,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type, Authorization"
                },
                body: JSON.stringify({ message: "Seller not found" }),
            };
        }

        console.log("Fetched seller data:", sellerData);

        // Fetch items based on seller ID
        const { items, sellerInfo } = await getSellerData(sellerData.idaccounts);

        // Merge sellerInfo from the accounts table if no items are found
        const combinedSellerInfo = sellerInfo || {
            first_name: sellerData.first_name,
            last_name: sellerData.last_name,
            email: sellerData.email,
            funds: sellerData.funds,
        };

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            body: JSON.stringify({ items, sellerInfo: combinedSellerInfo }),
        };
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            body: JSON.stringify({
                message: "Failed to retrieve items",
                error: error.message,
            }),
        };
    }
};