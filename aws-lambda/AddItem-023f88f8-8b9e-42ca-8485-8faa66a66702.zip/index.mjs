import mysql from 'mysql';

const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const addItem = (itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemStatus, itemType) => {
    return new Promise((resolve, reject) => {
        const sql = `INSERT INTO items (iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType, seller_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2);`;
        console.log('SQL Query:', sql);
        console.log('Values:', [itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemStatus, itemType]); // Log all parameters

        pool.query(sql, [itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemStatus, itemType], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};


export const handler = async (event) => {
    const iName = String(event.iName);
    const iDescription = String(event.iDescription);
    const iImage = String(event.iImage);
    const iStartingPrice = Number(event.iStartingPrice);

    const iStartDate = event.iStartDate ? Math.floor(new Date(event.iStartDate).getTime() / 1000) : null;
    const duration = event.duration ? Number(event.duration) * 24 * 60 * 60 : null;
    const iEndDate = (iStartDate && duration) ? iStartDate + duration : null;
    const iStatus = "inactive";
    const iType = event.iType && (event.iType === "Auction" || event.iType === "Buy_Now") 
        ? String(event.iType) 
        : "Auction"; // Default to "Auction" if not provided or invalid

    console.log('Inserting item:', { iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType });

    try {
        const result = await addItem(iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration, iStatus, iType);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Item added successfully",
                itemId: result.insertId,
            })
        };
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to add item",
                error: error.message
            })
        };
    }
};