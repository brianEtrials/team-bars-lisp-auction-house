import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to add an item to the database
const editItem = (itemName, itemDecrip, itemImage, itemPrice, itemDuration, item_ID) => {
    return new Promise((resolve, reject) => {
        const sql = `
            UPDATE items 
            SET 
                iName = ?, 
                iDescription = ?, 
                iImage = ?, 
                iStartingPrice = ?,  
                duration = ? 
            WHERE 
                item_ID = ?;
        `;  
        pool.query(sql, [itemName, itemDecrip, itemImage, itemPrice, itemDuration, item_ID], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

// Main handler function
export const handler = async (event) => {
    // Parse and prepare data from the event
    const item_ID = Number(event.item_ID); //
    const iName = String(event.iName);
    const iDescription = String(event.iDescription);
    const iImage = String(event.iImage); // S3 image URL from front end
    const iStartingPrice = Number(event.iStartingPrice);
    

    // Check if iStartDate and duration are provided
    const duration = event.duration ? Number(event.duration) * 24 * 60 * 60 : null; // Convert days to seconds

    // Log the item data before inserting into the database
    console.log('Editing item:', { iName, iDescription, iImage, iStartingPrice, duration });

    try {
        // Add the item to the database with the S3 image URL
        const result = await editItem(iName, iDescription, iImage, iStartingPrice, duration, item_ID);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Item edited successfully",
                affectedRows: result.affectedRows, // Number of rows updated
                itemId: item_ID// Capture and return the ID of the newly inserted item
            })
        };
    } catch (error) {
        // Handle possible errors during database interaction
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to edit item",
                error: error.message
            })
        };
    }
};
