import mysql from 'mysql';

// Create a connection pool
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});

// Function to query all items
const getAllItems = () => {
  return new Promise((resolve, reject) => {
    pool.query("SELECT item_ID, iName, seller_id, iStatus FROM items", (error, rows) => {
      if (error) return reject(error);
      return resolve(rows || []);
    });
  });
};

// Lambda handler
export const handler = async (event) => {
  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Query the database
    const items = await getAllItems();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ items }),
    };
  } catch (error) {
    console.error("Error fetching items:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Failed to retrieve items", error: error.message }),
    };
  }
};
