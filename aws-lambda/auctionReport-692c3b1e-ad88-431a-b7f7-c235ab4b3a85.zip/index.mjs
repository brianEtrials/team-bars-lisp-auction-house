import mysql from 'mysql';

// Create a connection pool to the database
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});

// Function to fetch auction report based on date range
const getAuctionReport = (startDate, endDate) => {
  return new Promise((resolve, reject) => {
    const startTimestamp = Math.floor(new Date(startDate).getTime() / 1000);
    const endTimestamp = Math.floor(new Date(endDate).setHours(23, 59, 59, 999) / 1000);

    const query = `
      SELECT 
        i.item_ID AS "Item ID",
        i.iName AS "Item Name",
        i.iNumBids AS "Total Bids",
        MAX(b.amount) AS "Sale Price",
        (SELECT b1.buyer_ID FROM bids b1 WHERE b1.item_ID = i.item_ID AND b1.amount = MAX(b.amount) LIMIT 1) AS "Buyer",
        i.seller_ID AS "Seller",
        i.iEndDate AS "Auction End Date",
        MAX(b.amount) * 0.05 AS "Commission Earned"
      FROM 
        items i
      LEFT JOIN 
        bids b ON i.item_ID = b.item_ID
      WHERE 
        i.iFullfilledTime IS NOT NULL 
        AND i.iEndDate BETWEEN ? AND ?
      GROUP BY 
        i.item_ID, i.iName, i.iNumBids, i.seller_ID, i.iEndDate;
    `;

    // Send the query with the converted timestamps
    pool.query(query, [startTimestamp, endTimestamp], (error, rows) => {
      if (error) return reject(error);
      return resolve(rows);
    });
  });
};

export const handler = async (event) => {
  try {
    if (!event.body) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Request body is missing" }),
      };
    }

    const { startDate, endDate } = JSON.parse(event.body);

    if (!startDate || !endDate) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Start date and end date are required" }),
      };
    }

    const auctionReport = await getAuctionReport(startDate, endDate);
    
    return {
      statusCode: 200,
      body: JSON.stringify({ auctionReport }),
    };
  } catch (error) {
    console.error("Error parsing event body:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to retrieve auction report",
        error: error.message,
      }),
    };
  }
};
