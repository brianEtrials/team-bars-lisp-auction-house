import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const fetchitems = () =>{
  return new Promise((resolve,reject)=>{
    // const sql ='Select * FROM items WHERE iStatus = "active";'
    const sql ='SELECT i.*,COALESCE(MAX(b.amount), i.iStartingPrice) AS highestBid FROM auction_data.items i LEFT JOIN auction_data.bids b ON i.item_ID = b.item_ID WHERE i.iStatus = "active" GROUP BY i.item_ID;'
    pool.query(sql,(error,result) => {
      if (error) return reject(error);

      if (result.length === 0 ){
        return resolve({items:[]})
      }

      const items = result.map(item =>({
        ...item,
        iStartDate: item.iStartDate ? new Date(item.iStartDate * 1000).toISOString().split('T')[0]:null,
        iEndDate: item.iEndDate ? new Date(item.iEndDate * 1000).toISOString().split('T')[0]:null,
      }))

      return resolve({items})
    });
  });
};

// const updatesStatuschangescompleted = () =>{
//   return new Promise((resolve,reject)=>{
//     const sql ='UPDATE items SET iStatus = "completed" WHERE FROM_UNIXTIME(iEndDate) < CURRENT_DATE() AND iNumBids > 0 AND iFullfilledTime = 0 AND iStatus != "completed";'
//     pool.query(sql,(error,result) => {
//       if (error) return reject(error);

//     });
//   });
// };

// const updatesStatuschangesfailed = () =>{
//   return new Promise((resolve,reject)=>{
//     const sql ='UPDATE items SET iStatus = "failed" WHERE FROM_UNIXTIME(iEndDate) < CURRENT_DATE() AND (iNumBids IS NULL OR iNumBids = 0) AND iStatus != "failed";'
//     pool.query(sql,(error,result) => {
//       if (error) return reject(error);

//     });
//   });
// };
export const handler = async (event) => {
  // TODO implement
  try{
    // await updatesStatuschangescompleted();
    // await updatesStatuschangesfailed();
    const itemdata = await fetchitems();
    console.log("Items fetched are : ", itemdata)
    const response = {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
    },
      body: JSON.stringify({itemdata}),
    };
    return response;
  }
  catch(error){
    console.error("Database error : ", error);
    return{
      statusCode:500,
      headers: {
        "Access-Control-Allow-Origin": "*",
    },
      body: JSON.stringify({
        message:"Failed to load items",
        error: error.message,
      })
    }

  }

};
