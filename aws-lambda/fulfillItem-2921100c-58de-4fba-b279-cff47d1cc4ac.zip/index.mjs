import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const getSeller = (item_ID) => {
  return new Promise((resolve, reject) => {
    console.log(`Fetching the seller_ID for item_ID: ${item_ID}`);
    pool.query("SELECT seller_ID FROM items WHERE item_ID = ? ", [item_ID], (error, rows) => {
      if (error) {
        console.error("Error querying database:", error);
        return reject(error);
      }
      if (rows.length === 0) {
        console.log("No account with that requirement.");
        return resolve(null);
      }
      return resolve(rows[0]);
    });
  });
};

// Function to update the status of the item in the database
const fulfilItem = (item_ID, iFullfilledTime) => {
    return new Promise((resolve, reject) => {
        const sql = `UPDATE items SET iStatus = 'fulfilled', iFullfilledTime = ? WHERE item_ID = ?;`;
        pool.query(sql, [iFullfilledTime, item_ID], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

const bidInformation = (item_ID) => {
    return new Promise((resolve, reject) => {
      console.log(`Fetching the highest bid for item_ID: ${item_ID}`);
      pool.query("SELECT buyer_ID, amount FROM bids WHERE bidStatus = 1 AND item_ID = ? ", [item_ID], (error, rows) => {
        if (error) {
          console.error("Error querying database:", error);
          return reject(error);
        }
        if (rows.length === 0) {
          console.log("No account with that requirement.");
          return resolve(null);
        }
        return resolve(rows[0]);
      });
    });
  };

  const manageFund = (buyer_ID, amount) => {
    return new Promise((resolve, reject) => {
      console.log(`Updating funds for user: ${buyer_ID} to new total: ${amount}`);
      const sql = `UPDATE accounts SET funds = ? WHERE idaccounts = ?`;
      pool.query(sql, [amount, buyer_ID], (error, results) => {
        if (error) {
          console.error("Error updating database:", error);
          return reject(error);
        }
        console.log("Update results:", results);
        return resolve(results);
      });
    });
  };

const readfunds = (buyer_ID) => {
return new Promise((resolve, reject) => {
    console.log("Fetching funds for buyer_ID:", buyer_ID);
    
    pool.query("SELECT funds FROM accounts WHERE idaccounts = ?", [buyer_ID], (error, rows) => {
    if (error) {
        console.error("Error querying database:", error);
        return reject(error);
    }
    console.log("Database rows fetched:", rows);

    // Check if any rows are returned
    if (rows.length === 0) {
        console.warn(`No account found for buyer_ID: ${buyer_ID}`);
        return resolve(null); // No account found
    }

    return resolve(rows[0]); // Return the first row (e.g., { funds: 100 })
    });
});
};

const recordTransaction = (seller_ID, buyer_ID, item_Id, amount, iFullfilledTime) => {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO transactions (seller_id, buyer_id, item_id, amount, transaction_time)
                 VALUES (?, ?, ?, ?, ?);`;  
    pool.query(sql, [seller_ID, buyer_ID, item_Id, amount, iFullfilledTime], (error, results) => {
        if (error) return reject(error);
        return resolve(results);
    });
});
};

// Main handler function
export const handler = async (event) => {

    let item_Id = Number(event.item_ID);
    const iFullfilledTime = Math.floor(Date.now() / 1000);
    console.log(Date.now(),'should be the same iFullfilledTime :', iFullfilledTime)

    if (isNaN(item_Id)) {
      return {
          statusCode: 400,
          body: JSON.stringify({ message: "Invalid item ID" })
      }
    };

    try {
        
        const sellerInfo = await getSeller(item_Id);
        const seller_ID = sellerInfo.seller_ID;
        const bidInfo = await bidInformation(item_Id);
        const buyer_ID = bidInfo.buyer_ID;
        const amount = bidInfo.amount;

        const result1 = await readfunds(buyer_ID);
        const result2 = await readfunds(seller_ID);
        console.log('result2 :', result2)

        const currentBuyerFund = result1.funds;
        const currentSellerFund = result2.funds;
        console.log('result2.funds :', result2.funds)

        const newBuyerFund = currentBuyerFund - amount;
        const newSelleFund = currentSellerFund + (amount * 0.95);

        await manageFund(seller_ID, newSelleFund);
        await manageFund(buyer_ID, newBuyerFund);
        console.log('iFullfilledTime: ', iFullfilledTime, 'item_Id: ', item_Id)
        const statusChange = await fulfilItem(item_Id, iFullfilledTime);
        console.log('statusChange :', statusChange)
        console.log('statusChange.warning :', statusChange.warning)
        await recordTransaction(seller_ID, buyer_ID, item_Id, amount, iFullfilledTime);

      const response = {
        statusCode: 200,
        body: JSON.stringify({         
          message: "Status updated successfully", 
        }), 
      };

      return response;

    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
                message: "Failed to update status",
                error: error.message,
            }),
        };

    } 
    
};
