import mysql from 'mysql';

// Create a connection pool
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});

// Function to query active items count
const getActiveItemsCount = () => {
  return new Promise((resolve, reject) => {
    pool.query(
      "SELECT COUNT(*) AS activeItemsCount FROM items WHERE iStatus = 'active'",
      (error, rows) => {
        if (error) return reject(error);
        return resolve(rows[0]?.activeItemsCount || 0);
      }
    );
  });
};

// Function to query total bids count
const getTotalBidsCount = () => {
  return new Promise((resolve, reject) => {
    pool.query(
      "SELECT SUM(iNumBids) AS totalBidsCount FROM items",
      (error, rows) => {
        if (error) return reject(error);
        return resolve(rows[0]?.totalBidsCount || 0);
      }
    );
  });
};

// Function to check and sum bids for items based on the conditions
const getBidsSumForCompletedItems = () => {
  return new Promise((resolve, reject) => {
    pool.query(
      `SELECT SUM(maxBidAmount) AS totalBidsAmount
       FROM (
         SELECT MAX(b.amount) AS maxBidAmount
         FROM items i
         JOIN bids b ON i.item_ID = b.item_ID
         WHERE i.iEndDate < NOW() 
           AND i.iNumBids > 0 
           AND i.iFullfilledTime IS NOT NULL
         GROUP BY i.item_ID
       ) AS maxBids`,
      (error, rows) => {
        if (error) return reject(error);
        return resolve(rows[0]?.totalBidsAmount || 0);
      }
    );
  });
};


// Lambda handler
export const handler = async (event) => {
  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Query the database
    const activeItemsCount = await getActiveItemsCount();
    const totalBidsCount = await getTotalBidsCount();
    const totalBidsAmount = await getBidsSumForCompletedItems();
    const revenueEarned = Math.round(totalBidsAmount * 0.05);

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ activeItemsCount, totalBidsCount, totalBidsAmount, revenueEarned }),
    };
  } catch (error) {
    console.error("Error fetching data:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Failed to retrieve data", error: error.message }),
    };
  }
};
