//readfunds
import mysql from 'mysql';

const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});


const readFunds = (usernamefetached) => {
  return new Promise((resolve, reject) => {
      pool.query("SELECT first_name, last_name, email, funds FROM accounts WHERE username = ?", [usernamefetached], (error, rows) => {
          if (error) return reject(error);
          return resolve(rows[0]); // Assuming idaccounts is unique
      });
  });
};


export const handler = async (event) => {
  try {
    console.log('Received event:', JSON.stringify(event, null, 2));
    const usernamefetached = event.queryStringParameters?.username || event.username;
    if (!usernamefetached) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "username is required" }),
      };
    }

    const account = await readFunds(usernamefetached);
    if (!account) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "Account not found" }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(account),
    };
  } catch (error) {
    console.error("Error reading funds:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Failed to retrieve funds", error: error.message }),
    };
  }
};
