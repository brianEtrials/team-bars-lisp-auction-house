import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to update the status of the item in the database
const setPendingStatus = (item_ID) => {
    return new Promise((resolve, reject) => {
        const sql = `UPDATE items SET iStatus = 'pending' WHERE item_ID = ? AND iStatus = 'frozen';`;
        pool.query(sql, [item_ID], (error, results) => {
            if (error) return reject(error);
            if (results.affectedRows === 0) {
                return reject(new Error("Item not found or not in frozen state."));
            }
            return resolve(results);
        });
    });
};

// Main handler function
export const handler = async (event) => {
    console.log("Received event:", JSON.stringify(event, null, 2));

    let item_Id = Number(event.item_ID);

    if (isNaN(item_Id)) {
      return {
          statusCode: 400,
          body: JSON.stringify({ message: "Invalid item ID" })
      };
    }

    try {
        await setPendingStatus(item_Id);

        const response = {
            statusCode: 200,
            body: JSON.stringify({         
                message: "Status updated to pending successfully", 
            }),
        };

        return response;

    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to update status",
                error: error.message,
            }),
        };
    } 
};
