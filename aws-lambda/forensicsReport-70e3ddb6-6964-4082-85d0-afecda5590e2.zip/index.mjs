import mysql from 'mysql';

const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data"
});

const getForensicsReport = () => {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT 
        i.item_ID AS "Item ID",
        i.iName AS "Item Name",
        i.iDescription AS "Item Description",
        i.iImage AS "Item Image",
        COALESCE(i.iNumBids, 0) AS "Total Bids", -- If no bids, default to 0
        i.iStatus AS "Status",
        i.iStartingPrice AS "Starting Price",
        i.duration AS "Duration",
        i.iEndDate AS "Auction End Date",
        COALESCE(MAX(b.amount), i.iStartingPrice) AS "Current/Final Price" -- Use Starting Price if no bids
      FROM 
        items i
      LEFT JOIN 
        bids b ON i.item_ID = b.item_ID
      WHERE 
        i.iStatus IN ('active', 'completed', 'fulfilled')
      GROUP BY 
        i.item_ID, i.iName, i.iDescription, i.iImage, i.iNumBids, i.iStatus, i.iStartingPrice, i.duration, i.iEndDate
      ORDER BY 
        CASE 
          WHEN i.iEndDate >= UNIX_TIMESTAMP() THEN 0 -- Future dates first
          ELSE 1 -- Past dates after
        END,
        i.iEndDate ASC; -- Sort by end date within each group

    `;

    pool.query(query, (error, rows) => {
      if (error) return reject(error);
      return resolve(rows);
    });
  });
};

export const handler = async (event) => {
  try {
    // Fetch the auction report with the updated filter
    const forensicsReport = await getForensicsReport();

    return {
      statusCode: 200,
      body: JSON.stringify({ forensicsReport }),
    };
  } catch (error) {
    console.error("Error retrieving auction report:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Failed to retrieve auction report",
        error: error.message,
      }),
    };
  }
};
