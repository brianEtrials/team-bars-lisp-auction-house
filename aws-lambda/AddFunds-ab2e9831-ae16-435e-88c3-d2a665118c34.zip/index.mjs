// Import the MySQL library
import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
  host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
  user: "auctionAdmin",
  password: "bars:auction",
  database: "auction_data",
  connectionLimit: 10 // Adjust this as needed
});

// Function to read funds from the database
const readfunds = (fetched_username) => {
  return new Promise((resolve, reject) => {
    console.log("Fetching funds for username:", fetched_username);
    
    pool.query("SELECT funds, freeFunds FROM accounts WHERE username = ?", [fetched_username], (error, rows) => {
      if (error) {
        console.error("Error querying database:", error);
        return reject(error);
      }
      console.log("Database rows fetched:", rows);

      // Check if any rows are returned
      if (rows.length === 0) {
        console.warn(`No account found for email: ${fetched_username}`);
        return resolve(null); // No account found
      }

      return resolve(rows[0]); // Return the first row (e.g., { funds: 100 })
    });
  });
};

// Function to update funds in the database
const addfunds = (fetched_username, newTotalFunds, newTotalFreeFunds) => {
  return new Promise((resolve, reject) => {
    console.log(`Updating funds for username: ${fetched_username} to new total: ${newTotalFunds}`);
    const sql = `UPDATE accounts SET funds = ?, freeFunds = ? WHERE username = ?`;
    pool.query(sql, [newTotalFunds, newTotalFreeFunds, fetched_username], (error, results) => {
      if (error) {
        console.error("Error updating database:", error);
        return reject(error);
      }
      console.log("Update results:", results);
      return resolve(results);
    });
  });
};

// Handler function for the API call
export const handler = async (event) => {
  try {


    // Extract email and funds
    const fetched_username = event.usernamedata;
    const fetched_funds = event.funds;

    console.log("Parsed email:", fetched_username, "Parsed funds:", fetched_funds);

    if (!fetched_username || fetched_funds === undefined) {
      throw new Error("Missing email or funds in request body");
    }

    // Fetch current funds from the database
    const account = await readfunds(fetched_username);

    if (!account || account.funds === undefined) {
      throw new Error("Account not found or invalid funds");
    }

    const currentFunds = parseFloat(account.funds);
    console.log(`Current funds for ${fetched_username}: ${currentFunds}`);

    const currentFreeFunds = parseFloat(account.freeFunds);
    console.log(`Current freeFunds for ${fetched_username}: ${currentFreeFunds}`);

    // Parse and validate the funds to add
    const amountToAdd = parseFloat(fetched_funds);
    if (isNaN(amountToAdd)) throw new Error("Invalid amount provided");

    // Calculate the new total funds
    const newTotalFunds = currentFunds + amountToAdd;
    console.log(`New total funds for ${fetched_username}: ${newTotalFunds}`);

    const newTotalFreeFunds = currentFreeFunds + amountToAdd;
    console.log(`New total freeFunds for ${fetched_username}: ${newTotalFreeFunds}`);

    // Update the funds in the database
    await addfunds(fetched_username, newTotalFunds, newTotalFreeFunds);

    // Return the updated funds
    const response = {
      statusCode: 200,
      body: JSON.stringify({
        message: "Funds updated successfully",
        newTotalFunds
      }),
    };
    return response;

  } catch (error) {
    // Error handling
    console.error("Error updating funds:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to update funds", error: error.message }),
    };
  }
};

