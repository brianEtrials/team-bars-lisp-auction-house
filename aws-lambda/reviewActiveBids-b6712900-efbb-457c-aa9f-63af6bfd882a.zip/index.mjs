import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

const fetchbids = (buyer_ID) => {
    return new Promise((resolve, reject) => {
        console.log("Fetching bids for buyer_ID:", buyer_ID);
        const sql = 'SELECT * FROM ItemBidsView WHERE buyer_ID = ?;';
        pool.query(sql, [buyer_ID], (error, result) => {
            if (error) {
                console.error("Database query error:", error);
                return reject(error);
            }

            const bids = result.map((bid) => ({
                iName: bid.iName,
                buyer_ID: bid.buyer_ID,
                item_ID: bid.item_ID,
                amount: bid.amount,
                Winning: bid.Winning,
                iEndDate: bid.iEndDate && !isNaN(bid.iEndDate)
                    ? new Date(bid.iEndDate * 1000).toISOString().split('T')[0]
                    : null,
                bidDate: bid.bidDate
            }));

            console.log("Bids found:", bids);
            return resolve({ bids });
        });
    });
};

const fetchbuyerData = (username) => {
    return new Promise((resolve, reject) => {
        console.log("Fetching buyer_ID for username:", username);
        const sql = 'SELECT idaccounts FROM accounts WHERE username = ?;';
        pool.query(sql, [username], (error, result) => {
            if (error) {
                console.error("Database query error:", error);
                return reject(error);
            }
            return resolve(result[0].idaccounts); // Return buyer_ID
        });
    });
};


export const handler = async (event) => {
    console.log("Received event:", event);

    const usernamefetached = event.queryStringParameters?.username || event.username;

    if (!usernamefetached || typeof usernamefetached !== 'string') {
        console.error("Invalid or missing username:", usernamefetached);
        return {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: "Valid username is required" }),
        };
    }

    try {

        const buyer_ID = await fetchbuyerData(usernamefetached);
        const biddata = await fetchbids(buyer_ID);
        console.log("Bids fetched are:", biddata);
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ biddata }),
        };
    } catch (error) {
        console.error("Database error:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
                message: "Failed to load bids",
                error: error.message,
            }),
        };
    }
};
