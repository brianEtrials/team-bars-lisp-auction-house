import AWS from 'aws-sdk';
const s3 = new AWS.S3();

export const handler = async (event) => {
    console.log("Lambda function started");
    try {
        let imageKey;
        console.log("Event received:", JSON.stringify(event));
        // Check if `imageKey` is directly in `event.body` or nested
        if (event.imageKey) {
            imageKey = event.imageKey;
            console.log("imageKey found in event:", imageKey);
        } else {
            const parsedBody = JSON.parse(event.body || '{}');
            imageKey = parsedBody.imageKey;
            console.log("imageKey found in parsed body:", imageKey);
        }

        // Throw an error if imageKey is not provided
        if (!imageKey) {
            console.error("imageKey is required but not provided");
            throw new Error("imageKey is required");
        }

        const params = {
            Bucket: 'uploadimage24', 
            Key: imageKey
        };
        console.log("Attempting to delete object:", params);

        // Perform the delete operation
        await s3.deleteObject(params).promise();
        console.log("Object deleted successfully");
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: 'Image deleted successfully' })
        };
    } catch (err) {
        console.error("imageKey is required but not provided");
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ message: 'Error deleting image', error: err.message || err })
        };
    }
};
