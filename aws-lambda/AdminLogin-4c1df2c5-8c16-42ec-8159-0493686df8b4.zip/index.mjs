export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  let body;

  if (event.body) {
    // Try to parse event.body as JSON
    try {
      body = JSON.parse(event.body);
    } catch (error) {
      console.error("Error parsing event.body:", error);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid request body format" }),
      };
    }
  } else {
    // Fallback to use event directly if event.body is undefined
    body = event;
  }

  console.log("Parsed body:", body);

  const { username, password } = body;

  const validCredentials = {
    username: "admin",
    password: "admin24",
  };

  if (username === validCredentials.username && password === validCredentials.password) {
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Admin login successful" }),
    };
  } else {
    return {
      statusCode: 401,
      body: JSON.stringify({ error: "Invalid admin credentials" }),
    };
  }
};
