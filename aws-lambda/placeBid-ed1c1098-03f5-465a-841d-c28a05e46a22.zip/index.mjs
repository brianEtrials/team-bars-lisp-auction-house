import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data",
    connectionLimit: 10 // Adjust this as needed
});

// Function to add a bid to the database
const placeBid = (buyer_ID, item_ID, amount, bidTimestamp) => {
    return new Promise((resolve, reject) => {
        const sql = `INSERT INTO bids (buyer_ID, item_ID, amount, bidTimestamp, bidStatus)
                    VALUES (?, ?, ?, ?, 1);`;

        pool.query(sql, [buyer_ID, item_ID, amount, bidTimestamp], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};
// function to change winning status of the previous bids.
const notHighest = (item_ID) => {
  return new Promise((resolve, reject) => {
    console.log("Updating bidStatus for all other bids");
    pool.query("UPDATE bids SET bidStatus = 0 WHERE item_ID = ?", [item_ID], (error, results) => {
      if (error) {
        console.error("Error querying database:", error);
        return reject(error);
      }
      console.log("Update results:", results); 
      return resolve(results); 
    });      
  });
};

// function to find the buyerID and amount for the previous winning bid
const prevBID = (item_ID) => {
    return new Promise((resolve, reject) => {
        console.log(`Fetching the highest bid info for item_ID: ${item_ID}`);
        let sql = "SELECT buyer_ID, amount FROM bids WHERE bidStatus = 1 AND item_ID = ?";
        const params = [item_ID];

        pool.query(sql, params, (error, rows) => {
            if (error) {
                console.error("Error querying database:", error);
                return reject(error);
            }
            if (rows.length === 0) {
                console.log("No current highest bid found.");
                return resolve(0);
            }
            return resolve(rows[0]);
        });
    });
};

// Function to read funds from the database
const readfunds = (buyer_ID) => {
    return new Promise((resolve, reject) => {
      console.log("Fetching funds for buyer_ID:", buyer_ID);
      
      pool.query("SELECT freeFunds FROM accounts WHERE idaccounts = ?", [buyer_ID], (error, rows) => {
        if (error) {
          console.error("Error querying database:", error);
          return reject(error);
        }
        console.log("Database rows fetched:", rows);
  
        // Check if any rows are returned
        if (rows.length === 0) {
          console.warn(`No account found for buyer_ID: ${buyer_ID}`);
          return resolve(null); // No account found
        }
  
        return resolve(rows[0]); // Return the first row (e.g., { funds: 100 })
      });
    });
  };

// Function to update funds in the database
const managefreeFund = (buyer_ID, newFreeFunds) => {
    return new Promise((resolve, reject) => {
      console.log(`Updating freeFunds for buyer_ID: ${buyer_ID} to new total: ${newFreeFunds}`);
      const sql = `UPDATE accounts SET freeFunds = ? WHERE idaccounts = ?`;
      pool.query(sql, [newFreeFunds, buyer_ID], (error, results) => {
        if (error) {
          console.error("Error updating database:", error);
          return reject(error);
        }
        console.log("Update results:", results);
        return resolve(results);
      });
    });
  };
  
  // changes the number of bids of an item in the items table
const addnumBids = (item_ID) => {
    return new Promise((resolve, reject) => {
      console.log(`Incrementing iNumBids for item_ID: ${item_ID}`);
      const sql = `UPDATE items SET iNumBids = COALESCE(iNumBids, 0) + 1 WHERE item_ID = ?`;
      pool.query(sql, [item_ID], (error, results) => {
        if (error) {
          console.error("Error updating database:", error);
          return reject(error);
        }
        console.log("Update results:", results);
        return resolve(results);
      });
    });
  };

  // Function to read ID from the database 
const readid = (buyer_username) => {
return new Promise((resolve, reject) => {
  console.log("Fetching id for username:", buyer_username);
  
  pool.query("SELECT idaccounts FROM accounts WHERE username = ?", [buyer_username], (error, rows) => {
    if (error) {
      console.error("Error querying database:", error);
      return reject(error);
    }
    console.log("Database rows fetched:", rows);

    // Check if any rows are returned
    if (rows.length === 0) {
      console.warn(`No account found for email: ${buyer_username}`);
      return resolve(null); // No account found
    }

    return resolve(rows[0]); // Return the first row (e.g., { funds: 100 })
  });
});
};

const checkBuyer = (buyer_ID, item_ID) => {
  return new Promise((resolve, reject) => {
    console.log("Checking if buyer_ID already placed a bid for item_ID:", item_ID);

    const query = "SELECT COUNT(*) AS count FROM bids WHERE buyer_ID = ? AND item_ID = ? AND bidStatus = 1";
    pool.query(query, [buyer_ID, item_ID], (error, results) => {
      if (error) {
        console.error("Error querying database:", error);
        return reject(error);
      }

      console.log("Database query result:", results);

      // Check if any rows exist for the buyer_ID
      const count = results[0].count;
      if (count > 0) {
        console.log(`Entry found for buyer_ID: ${buyer_ID}`);
        resolve(true); // Entry exists
      } else {
        console.log(`No entry found for buyer_ID: ${buyer_ID}`);
        resolve(false); // Entry does not exist
      }
    });
  });
};

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Main handler function
export const handler = async (event) => {
    console.log("Handler | Event received:", event);

    // Parse and validate input data
    const buyer_username = event.usernamedata 
    console.log("Handler | buyer_username:", event.usernamedata);

    // const buyer_ID = event.buyer_ID;
    const buyer_IDresult = await readid(buyer_username); 
    console.log("Handler | buyerIDresult: ", buyer_IDresult);

    const buyer_ID = buyer_IDresult.idaccounts
    console.log("Fetched user ID: ", buyer_ID);

    console.log("Handler | item_ID:", event.item_ID);
    const item_ID = event.item_ID;

    console.log("Handler | amount:", event.funds);
    const amount = event.funds;

    // Ensure required parameters are provided
    if (!buyer_ID || !item_ID || !amount) {
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: "Missing required parameters: buyer_ID, item_ID, or amount",
            }),
        };
    }

    // Generate a Unix timestamp for the bid
    const bidTimestamp = Math.floor(Date.now() / 1000);

    // Log the bid data
    console.log('Information of bid:', { buyer_ID, item_ID, amount, bidTimestamp });

    try {
        // Check if the buyer already has a bid on this item.
        
        const check = await checkBuyer(buyer_ID, item_ID);
        if (check === true) {
             return {
                 statusCode: 400,
                body: JSON.stringify({
                    message: `Buyer already has a winning bid on this item.`,
                 }),
             };
         }
         await notHighest(item_ID);
        
        // Fetch freeFunds from the database
        console.log("buyer id fetch for readfunds...........................")
        const account = await readfunds(buyer_ID);
        if (!account || account.freeFunds === undefined) {
            throw new Error("Account not found or invalid funds");
        }

        if (account.freeFunds < amount) {
          return {
              statusCode: 400,
              body: JSON.stringify({
                  message: `Buyer has insufficient funds.`,
              }),
          };
      }
        console.log('Blah blah') 
        // Fetch the current highest bid amount
        const oldHighestBid = await prevBID(item_ID);
        console.log('oldHighestBid: ', oldHighestBid);

        console.log('Handler | count highest bid ');

          
      if (oldHighestBid.count > 0) {

          console.log('oldHighestBid.amount: ', oldHighestBid.amount)
  
  
          const oldBuyer = oldHighestBid.buyer_ID; // buyer id of previous highest bidder
          const oldBuyerAccount = await readfunds(oldBuyer); // account info of previous highest bidder
          const oldFreeFunds = oldBuyerAccount.freeFunds; // current freeFunds in previous highest bidder account
  
          const updatedOldFreeFunds = oldFreeFunds + oldHighestBid.amount; // returning his benjamins to the old bidder.
  
          await managefreeFund(oldBuyer, updatedOldFreeFunds);
      }

        const currentFunds = account.freeFunds;
        console.log(`Current funds for ${buyer_ID}: ${currentFunds}`);

        const newFreeFunds = currentFunds - amount;
        console.log(`New total freeFunds for ${buyer_ID}: ${newFreeFunds}`);

        await managefreeFund(buyer_ID, newFreeFunds);

        await addnumBids(item_ID);

        // Add the bid to the database


        const result = await placeBid(buyer_ID, item_ID, amount, bidTimestamp);
        console.log('result of placing the bid: ', result)
        
        //const bid_ID = result.insertId; // nope. dont use this. this is supposed to be the last step.

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Bid placed successfully",
                bid_ID: result.insertId, // Return the bid_ID of the newly inserted row
            }),
        };
    } catch (error) {
        // Handle database interaction errors
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to place bid",
                error: error.message,
            }),
        };
    }
};
