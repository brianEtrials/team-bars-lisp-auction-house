import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to get all items from the database
const getItems = () => {
    return new Promise((resolve, reject) => {
        const sql = `SELECT * FROM items`;
        pool.query(sql, (error, results) => {
            if (error) return reject(error);
            resolve(results);
        });
    });
};

// Main handler function
export const handler = async () => {
    try {
        const items = await getItems();
        return {
            statusCode: 200,
            body: JSON.stringify({ items }),
        };
    } catch (error) {
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to retrieve items",
                error: error.message,
            }),
        };
    }
};
