import mysql from 'mysql';

// Set up a connection pool to the database
const pool = mysql.createPool({
    host: "auctionhousedb.crc48ss6s75k.us-east-1.rds.amazonaws.com",
    user: "auctionAdmin",
    password: "bars:auction",
    database: "auction_data"
});

// Function to add an item to the database
const addItem = (itemId, itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemAction) => {
    return new Promise((resolve, reject) => {
        const sql = `INSERT INTO items (ID, Name, Description, Image, Price, StartDate, EndDate, Duration, Action)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);`;
        pool.query(sql, [itemId, itemName, itemDecrip, itemImage, itemPrice, itemStartDate, itemEndDate, itemDuration, itemAction], (error, results) => {
            if (error) return reject(error);
            return resolve(results);
        });
    });
};

// Main handler function
export const handler = async (event) => {
    // Parse and prepare data from the event
    let item_Id = Number(event.iD);
    let iName = String(event.name);
    let iDescription = String(event.description);
    let iImage = String(event.image);
    let iStartingPrice = Number(event.price);
    let iStartDate = Number(event.startDate);
    let duration = Number(event.iduration);
    let iEndDate = iStartDate + duration;

    try {
        // Add the item to the database
        const result = await addItem(item_Id, iName, iDescription, iImage, iStartingPrice, iStartDate, iEndDate, duration);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Item added successfully",
                itemId: result.insertId // Capture and return the ID of the newly inserted item
            })
        };
    } catch (error) {
        // Handle possible errors during database interaction
        console.error('Database error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to add item",
                error: error.message
            })
        };
    } finally {
        // Ensure the database connection pool is closed after operations are complete
        pool.end();
    }
};
